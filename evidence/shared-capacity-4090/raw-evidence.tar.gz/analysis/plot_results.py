"""Render every shared-capacity repetition without imputing unavailable rates."""

import argparse
import hashlib
import html
import json
import math
from pathlib import Path

COLORS = ("#00796b", "#b35b00", "#496c9b")


def text(x, y, value, size=13, anchor="start", color="#263238", weight="400"):
    """Return escaped, accessible SVG text."""
    return (
        f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" '
        f'text-anchor="{anchor}" fill="{color}" font-weight="{weight}">'
        f"{html.escape(str(value))}</text>"
    )


def validate(report):
    """Require the final matrix, retaining ineligible trials as unavailable."""
    repeats = report["planned_repetitions"]
    if repeats != 3 or not report["planned_order_valid"]:
        raise ValueError("Expected the frozen three-repetition matrix")
    trials = {trial["name"]: trial for trial in report["trials"]}
    expected = {
        f"{condition}-{r}"
        for condition in ("urgent", "bulk", "fifo", "reserved")
        for r in range(repeats)
    }
    if set(trials) != expected or len(report["trials"]) != len(expected):
        raise ValueError("Missing or duplicate trials")
    for trial in trials.values():
        if (
            trial["status"] not in ("complete", "ineligible")
            or not trial["summary"]["complete"]
        ):
            raise ValueError("Do not plot a partial matrix as final evidence")
    return trials


def panel(trials, consumer, left, title, metric, percent=False):
    """Plot points for all eligible repetitions and text for unavailable ones."""
    conditions = (consumer, "fifo", "reserved")
    values = []
    unavailable = []
    for condition in conditions:
        for repeat in range(3):
            trial = trials[f"{condition}-{repeat}"]
            value = trial["summary"]["consumers"][consumer][metric]
            if (
                trial["status"] != "complete"
                or not trial["summary"]["capacity_eligible"]
            ):
                value = None
                unavailable.append(trial["name"])
            elif (
                value is None
                or not math.isfinite(value)
                or value < 0
                or (percent and value > 1)
            ):
                raise ValueError(f"Eligible trial has invalid metric: {trial['name']}")
            values.append((condition, repeat, value))
    top, bottom, width = 120, 345, 435
    maximum = (
        1.0
        if percent
        else max(
            1.0, math.ceil(max((v for _, _, v in values if v is not None), default=1))
        )
    )
    output = [
        text(left, 64, title, 18, weight="600"),
        text(
            left,
            86,
            "All scheduled urgent requests (%)"
            if percent
            else "Normal bulk completions/s, including drain",
            12,
        ),
    ]
    for tick in range(6):
        fraction = tick / 5
        y = bottom - fraction * (bottom - top)
        value = fraction * maximum
        output.append(
            f'<line x1="{left}" y1="{y}" x2="{left + width}" y2="{y}" stroke="#dce3e7"/>'
        )
        output.append(
            text(
                left - 9,
                y + 4,
                f"{value * 100:.0f}" if percent else f"{value:.1f}",
                11,
                "end",
                "#546e7a",
            )
        )
    for group, condition in enumerate(conditions):
        center = left + 72 + group * 145
        output.append(
            text(
                center,
                389,
                "Isolated" if group == 0 else "FIFO" if group == 1 else "Reserved",
                14,
                "middle",
                weight="600",
            )
        )
        for _, repeat, value in (row for row in values if row[0] == condition):
            x = center + (repeat - 1) * 42
            output.append(text(x, 365, f"R{repeat + 1}", 11, "middle", COLORS[repeat]))
            if value is None:
                output.append(text(x, 410, "N/A", 11, "middle", "#657780"))
                continue
            y = bottom - value / maximum * (bottom - top)
            if repeat == 0:
                output.append(
                    f'<circle cx="{x}" cy="{y:.2f}" r="5" fill="{COLORS[repeat]}"/>'
                )
            elif repeat == 1:
                output.append(
                    f'<rect x="{x - 5}" y="{y - 5:.2f}" width="10" height="10" fill="{COLORS[repeat]}"/>'
                )
            else:
                output.append(
                    f'<path d="M {x} {y - 6:.2f} L {x + 6} {y + 5:.2f} L {x - 6} {y + 5:.2f} Z" fill="{COLORS[repeat]}"/>'
                )
            label = f"{value * 100:.1f}" if percent else f"{value:.2f}"
            output.append(text(x, y - 12, label, 11, "middle", COLORS[repeat]))
    if unavailable:
        output.append(
            text(
                left,
                435,
                "Unavailable: " + ", ".join(unavailable) + " (capacity-ineligible)",
                11,
                color="#657780",
            )
        )
    return "\n".join(output)


def render(report, digest):
    """Produce a portable SVG in the existing scaling figure palette."""
    trials = validate(report)
    urgent = panel(
        trials,
        "urgent",
        65,
        "Urgent work completed within five seconds",
        "deadline_attainment",
        percent=True,
    )
    bulk = panel(
        trials,
        "bulk",
        595,
        "Bulk progress while sharing capacity",
        "completed_per_s_including_drain",
    )
    return f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1080 520" role="img" aria-labelledby="title desc">
<title id="title">Urgent deadline attainment and bulk throughput for every repetition</title>
<desc id="desc">Three repetitions of isolated, FIFO and reserved admission. Unavailable measurements are labelled N/A rather than plotted at zero. Warmed repeated inputs from 56 CORD receipts. Normal completion does not establish correct OCR.</desc>
<metadata>Source report SHA-256: {digest}</metadata>
<rect width="1080" height="520" fill="#ffffff"/>
<g font-family="DejaVu Sans, Arial, sans-serif">
{text(540, 28, "RTX 4090 · one Nemotron backend · each point is one repetition", 17, "middle", weight="600")}
{urgent}
{bulk}
{text(65, 472, "Warmed, repeated inputs: 56 CORD receipts. R1–R3 identify individual trials; no confidence intervals.", 12)}
{text(65, 495, "Normal completion is not OCR correctness. Unavailable capacity evidence is not a zero-throughput measurement.", 12)}
</g></svg>"""


def main():
    """Write a new figure from a finished report without replacing evidence."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    raw = args.input.read_bytes()
    svg = render(json.loads(raw), hashlib.sha256(raw).hexdigest())
    with args.output.open("x") as stream:
        stream.write(svg + "\n")
    print(
        json.dumps(
            {
                "output": str(args.output),
                "source_sha256": hashlib.sha256(raw).hexdigest(),
            }
        )
    )


if __name__ == "__main__":
    main()
