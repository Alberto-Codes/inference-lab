"""Independently audit a completed shared-capacity matrix without model access."""

import argparse
import hashlib
import json
import math
import sys
from collections import Counter
from pathlib import Path

sys.dont_write_bytecode = True


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def occupancy(records, accounting_end=None):
    """Retain uncertain backend work through the accounting window, never infer cancellation."""
    events = []
    for row in records:
        began = row.get("dispatch_offset_s")
        if began is None:
            continue
        ended = row["finished_offset_s"]
        if row.get("backend_execution_unknown"):
            require(accounting_end is not None and accounting_end >= ended, "Unknown execution needs an accounting horizon")
            ended = accounting_end
        require(0 <= began <= ended, "Invalid dispatch/completion interval")
        if ended == began:
            continue
        events.extend([(began, 1, row["consumer"]), (ended, -1, row["consumer"])])
    active = Counter()
    peak = Counter()
    previous = 0.0
    occupied_seconds = Counter()
    for when, delta, consumer in sorted(events):
        for key in ("all", "bulk", "urgent"):
            occupied_seconds[key] += active[key] * (when - previous)
        previous = when
        active[consumer] += delta
        active["all"] += delta
        require(min(active.values()) >= 0, "Negative reconstructed occupancy")
        for key in active:
            peak[key] = max(peak[key], active[key])
    require(all(value == 0 for value in active.values()), "Unclosed occupancy")
    return {"peak": dict(peak), "conservative_accounted_slot_seconds": dict(occupied_seconds)}


def uncertainty_audit(records, arm_end, capacity_eligible):
    """Prove fail-closed dispatch while retaining unknown work through the arm."""
    unknown = [r for r in records if r.get("backend_execution_unknown")]
    first = min((r["finished_offset_s"] for r in unknown), default=None)
    if first is not None:
        require(not capacity_eligible, "Backend uncertainty incorrectly capacity eligible")
        require(all(r["dispatch_offset_s"] < first for r in records if r.get("dispatch_offset_s") is not None),
                "Actual dispatch continued after observed backend uncertainty")
    return {"unknown_requests": [r["index"] for r in unknown],
            "first_observed_uncertainty_s": first,
            "no_actual_dispatch_after_uncertainty": True if unknown else None,
            "accounting_horizon_s": arm_end,
            "unknown_execution_termination": "Not inferred from client failure. Retained through accounting horizon; next arm requires owned parser reset." if unknown else None}


def canonical_trace(manifest, settings):
    """Construct expected identities independently of the runner's trace code."""
    arrivals = []
    sequence = 0
    while sequence / settings["urgent_rate"] < settings["duration"]:
        arrivals.append((sequence / settings["urgent_rate"], "urgent", sequence))
        sequence += 1
    burst = 0
    while burst * settings["burst_interval"] < settings["duration"]:
        for offset in range(settings["burst_size"]):
            arrivals.append((burst * settings["burst_interval"], "bulk", burst * settings["burst_size"] + offset))
        burst += 1
    result = []
    for index, (due, consumer, seq) in enumerate(sorted(arrivals)):
        item = manifest["pages"][seq % len(manifest["pages"])]
        result.append({"index": index, "consumer": consumer, "sequence": seq,
                       "scheduled_offset_s": due, "page_index": seq % len(manifest["pages"]),
                       "id": item["id"], "sha256": item["sha256"], "reference": item["reference"]})
    return result


def audit(root):
    require((root / "summaries.json").exists(), "Matrix not complete: summaries.json absent; do not audit partial results as final")
    protocol = read(root / "protocol.json")
    frozen = root / "frozen-source"
    sys.path[:0] = [str(frozen / "scripts"), str(frozen / "src")]
    from score_shared_capacity import summarize
    from report_scaling import resources

    manifest, settings = protocol["manifest"], protocol["settings"]
    require([p["id"] for p in manifest["pages"]] == list(range(24, 80)), "Primary corpus identities changed")
    require(manifest["evaluation_rows"] == list(range(80, 100)), "Holdout reservation changed")
    require(len({p["sha256"] for p in manifest["pages"]}) == 56, "Duplicate source images")
    require(settings["urgent_deadline"] == 5 and settings["duration"] == 300, "Primary deadline/window changed")
    require(settings["concurrency"] == 8 and settings["reserved"] == 2, "Primary upstream policy changed")
    expected_order = []
    for stage in (("urgent", "bulk"), ("fifo", "reserved")):
        for repeat in range(3):
            for condition in stage if repeat % 2 == 0 else stage[::-1]:
                expected_order.append({"name": f"{condition}-{repeat}", "condition": condition})
    require(protocol["order"] == expected_order, "Planned rotation differs")
    for name, digest in protocol["source_sha256"].items():
        require(sha(frozen / name) == digest, f"Frozen source changed: {name}")
        require(sha(root / "run-context" / "source" / name) == digest, f"Runtime source snapshot differs: {name}")
    expected = canonical_trace(manifest, settings)
    require(len(expected) == 1500, "Primary trace count differs")
    runtime = read(root / "run-context" / "runtime.json")
    common_profile = runtime["profile"]
    common_image = runtime["container"]["Image"]
    require(common_profile["revision"] == "62cb1e4ba153d113ff64aaf2be6e068c377cf53c", "Model revision differs")
    image_packages = read(root / "image-package-versions.json")
    require(image_packages["image"] == common_image, "Package metadata is not bound to the measured immutable image")
    require(image_packages["versions"]["vllm"] == common_profile["vllm"] and
            image_packages["versions"]["nemotron-parse"] == common_profile["plugin"],
            "Pinned package versions differ in image metadata")
    summaries = read(root / "summaries.json")["conditions"]
    require([x["name"] for x in summaries] == [x["name"] for x in expected_order], "Actual completed order differs")
    arms = []
    seen_containers = set()
    previous_end = None
    for arm in expected_order:
        name, condition = arm["name"], arm["condition"]
        directory = root / name
        plan = read(directory / "plan.json")
        require(plan["condition"] == condition and plan["settings"] == settings, f"Settings differ: {name}")
        require(plan["manifest"] == manifest and plan["profile"] == common_profile, f"Inputs/profile differ: {name}")
        require(plan["retries"] == 0 and plan["cache"] == "warmed repeated inputs", f"Retry/cache policy differs: {name}")
        require(sha(directory / "trace.json") == plan["trace_sha256"], f"Trace hash differs: {name}")
        require(read(directory / "trace.json")["requests"] == expected, f"Trace differs: {name}")
        require(plan["runner_sha256"] == protocol["source_sha256"]["scripts/shared_capacity.py"], f"Runner hash differs: {name}")
        require(plan["client_sha256"] == protocol["source_sha256"]["src/inference_lab/client.py"], f"Client hash differs: {name}")
        jobs = [x for x in expected if condition in ("fifo", "reserved") or x["consumer"] == condition]
        targets = {j["index"]: j for j in jobs}
        rows = [read(p) for p in sorted((directory / "terminal").glob("*.json"))]
        require(len(rows) == len(targets) and {r["index"] for r in rows} == set(targets), f"Terminal identities incomplete/duplicated: {name}")
        require({p.stem for p in (directory / "decisions").glob("*.json")} == {f"{i:09}" for i in targets}, f"Policy identities differ: {name}")
        for row in rows:
            job = targets[row["index"]]
            require(all(row.get(k) == v for k, v in job.items()), f"Terminal trace identity differs: {name}/{row['index']}")
            require(row["policy"] == condition and row["policy_decision"], "Policy missing")
            require(math.isfinite(row["e2e_s"]) and math.isclose(row["e2e_s"], row["finished_offset_s"] - job["scheduled_offset_s"], abs_tol=1e-8), "Latency does not start at scheduled arrival")
            if row["dispatch_offset_s"] is not None:
                require(math.isclose(row["queue_s"], row["dispatch_offset_s"] - job["scheduled_offset_s"], abs_tol=1e-8), "Queue time differs")
                limit = settings["urgent_deadline"] if row["consumer"] == "urgent" else settings["bulk_wait"]
                require(row["queue_s"] < limit, "Dispatched already-expired request")
        report = summarize(directory)
        require(report["complete"], f"Scorer found incomplete evidence: {name}")
        measured = read(directory / "measurement-start.json")["unix_s"]
        if previous_end is not None:
            require(measured >= previous_end, "Measured conditions overlap or are out of order")
        previous_end = measured + report["runtime"]["elapsed_s"]
        accounting_end = max(settings["duration"], report["runtime"]["elapsed_s"])
        uncertainty = uncertainty_audit(rows, accounting_end, report["capacity_eligible"])
        observed = occupancy(rows, accounting_end)
        require(observed["peak"].get("all", 0) <= settings["concurrency"], f"Upstream bound exceeded: {name}")
        if condition == "reserved":
            require(observed["peak"].get("bulk", 0) <= settings["concurrency"] - settings["reserved"], "Reserved bulk bound exceeded")
        for consumer in ("urgent", "bulk"):
            selected = [r for r in rows if r["consumer"] == consumer]
            scheduled = sum(j["consumer"] == consumer for j in jobs)
            require(report["consumers"][consumer]["scheduled"] == scheduled, "Scheduled denominator differs")
            if selected:
                require(71 in {r["id"] for r in selected}, "Receipt71 absent from consumer")
            if consumer == "urgent" and scheduled:
                attained = sum(r["status"] == "success" and r["e2e_s"] <= settings["urgent_deadline"] for r in selected)
                require(report["consumers"][consumer]["deadline_met"] == attained, "Deadline numerator differs")
                require(report["consumers"][consumer]["deadline_attainment"] == attained / scheduled, "Deadline denominator differs")
        warmups = [read(p) for p in sorted((directory / "warmup").glob("*.json"))]
        require(len(warmups) == 56 and [w["sha256"] for w in warmups] == [p["sha256"] for p in manifest["pages"]], f"Warmup inputs differ: {name}")
        container = read(root / f"runtime-{name}.json")["container"]
        require(container["Image"] == common_image and container["Config"]["Cmd"] == common_profile["arguments"], f"Runtime image/arguments differ: {name}")
        require(container["Id"] not in seen_containers, "Parser not reset between arms")
        seen_containers.add(container["Id"])
        for key, value in common_profile["environment"].items():
            require(f"{key}={value}" in container["Config"]["Env"], f"Runtime environment differs: {name}")
        arms.append({"name": name, "scheduled": len(jobs), "terminal": len(rows),
                     "condition": condition, "trace_sha256": plan["trace_sha256"],
                     "capacity_eligible": report["capacity_eligible"], "occupancy": observed, "uncertainty": uncertainty,
                     "status_counts": dict(Counter(r["status"] for r in rows)),
                     "receipt71_counts": dict(Counter(r["consumer"] for r in rows if r["id"] == 71)),
                     "resources": resources(directory, [{"scheduled_unix_s": measured}], settings["duration"]),
                     "source_terminal_sha256": report["terminal_sha256"], "container_id": container["Id"]})
    lifecycle = read(root / "lifecycle.json")
    require(lifecycle["restoration_verified"] and not lifecycle["restoration_errors"], "Service restoration not verified")
    restored = read(root / "live-restoration-check.json")
    require(restored["service_active"] and restored["owned_parser_absent"] and
            restored["loaded_models"] == lifecycle["previous_models"] and
            restored["expected_models"] == lifecycle["previous_models"] and
            restored["lifecycle_restoration_verified"], "Live restoration receipt differs")
    gpu = read(root / "gpu-test.json")
    require(gpu["returncode"] == 0 and "1 passed" in gpu["stdout"], "Real GPU check did not pass")
    return {"status": "passed", "arms": arms, "scheduled_total": sum(a["scheduled"] for a in arms),
            "capacity_eligible_arms": sum(a["capacity_eligible"] for a in arms),
            "protocol_sha256": sha(root / "protocol.json"), "audit_source_sha256": sha(Path(__file__)),
            "runtime_sha256": sha(root / "run-context" / "runtime.json"),
            "lifecycle": lifecycle, "lifecycle_sha256": sha(root / "lifecycle.json"),
            "live_restoration_sha256": sha(root / "live-restoration-check.json"),
            "image_package_versions_sha256": sha(root / "image-package-versions.json"),
            "gpu_test_sha256": sha(root / "gpu-test.json"),
            "limitations": ["Known responses retain slots through client-observed completion. Unknown execution retains slots through the accounting horizon, without claiming backend termination there. No further dispatch plus verified per-arm owned reset bounds later work; exact GPU execution intervals remain unknown.",
                            "The combined urgent-priority and reserved-capacity policy has no priority-only ablation; its components cannot be separated causally.",
                            "Workstation scheduling jitter can delay arrival processing and expiry observation beyond configured queue bounds. Preserve such outcomes and do not assign an unmeasured cause.",
                            "Capacity-ineligible arms remain invalid even if accounting passes.",
                            "Source/image identities and recorded restoration are checked; this audit does not rerun inference or query live services.",
                            "Resource averages use sampled arrival-window observations, not time-weighted continuous measurements.",
                            "OCR diagnostic scoring is reused; no independent human text-correctness adjudication is added.",
                            "Warm repeated receipts do not establish fresh-input or enterprise capacity."]}


def self_test():
    values = occupancy([{"consumer": "bulk", "dispatch_offset_s": 0, "finished_offset_s": 2},
                        {"consumer": "urgent", "dispatch_offset_s": 1, "finished_offset_s": 3},
                        {"consumer": "bulk", "dispatch_offset_s": 2, "finished_offset_s": 4}])
    require(values["peak"] == {"bulk": 1, "all": 2, "urgent": 1}, "Occupancy tie handling failed")
    require(values["conservative_accounted_slot_seconds"] == {"all": 6.0, "bulk": 4.0, "urgent": 2.0}, "Occupancy integration failed")
    uncertain = [{"index": 0, "consumer": "bulk", "dispatch_offset_s": 0,
                  "finished_offset_s": 2, "backend_execution_unknown": True},
                 {"index": 1, "consumer": "urgent", "dispatch_offset_s": 1,
                  "finished_offset_s": 3}]
    require(occupancy(uncertain, 5)["conservative_accounted_slot_seconds"]["bulk"] == 5,
            "Unknown backend slot was released early")
    require(uncertainty_audit(uncertain, 5, False)["first_observed_uncertainty_s"] == 2,
            "Uncertainty boundary differs")
    invalid = uncertain + [{"index": 2, "consumer": "bulk", "dispatch_offset_s": 2.1,
                            "finished_offset_s": 3}]
    try:
        uncertainty_audit(invalid, 5, False)
    except ValueError:
        pass
    else:
        raise AssertionError("Dispatch after uncertainty was accepted")
    print("Independent occupancy and fail-closed uncertainty self-tests passed")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
    else:
        if args.input is None or args.output is None:
            parser.error("--input and --output are required")
        result = audit(args.input.resolve())
        with args.output.open("x") as stream:
            json.dump(result, stream, indent=2)
        print(json.dumps({"status": result["status"], "scheduled_total": result["scheduled_total"], "capacity_eligible_arms": result["capacity_eligible_arms"]}))
